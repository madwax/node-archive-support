var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var session = require('express-session')

var routersPublic = require( "./routers.public.js" )

var app = express();

app.set('views', __dirname + '/public');
app.set('view engine', 'ejs');

app.use( express.static( "./public" ) );

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret : "SHUUUUSH",
    saveUninitialized: true,
    resave : false
}))

// attaching routes to the application
app.use(routersPublic);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});


app.listen( 8991 );

var express = require('express');
var router = express.Router();

var bigCounter = 0;


router.get('/', function(req, res)
{
	console.log( "We have a root request" );

  res.render('index', { _counterValue:bigCounter });

  ++bigCounter;

} );

module.exports = router;
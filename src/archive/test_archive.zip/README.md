This is the source code of [Express 4 Tutorial - Simple Server](http://danialk.github.io/blog/2014/12/05/express-4-tutorial-simple-server/) on my [blog](danialk.github.io).

To run the code:

* Clone the repo
* Install the dependencies
	``` npm install ```
* Run
	``` npm start ```